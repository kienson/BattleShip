var searchData=
[
  ['board_0',['Board',['../structBoard.html',1,'']]],
  ['boat_1',['Boat',['../structBoat.html',1,'']]]
];
